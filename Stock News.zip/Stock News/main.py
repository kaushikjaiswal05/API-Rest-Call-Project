import requests
from twilio.rest import Client
STOCK_NAME = "TSLA"
COMPANY_NAME = "Tesla Inc"

STOCK_ENDPOINT = "https://www.alphavantage.co/query"
NEWS_ENDPOINT = "https://newsapi.org/v2/everything"
STOCK_APIKEY = "3BA94I2R3Z9XTD6P"
NEWS_APIKEY = "d1215ba5cf224024bb819d9d18c100f2"

TWILIO_SID = "AC0ce789b9387c3c0f993cfdb849747490"
TWILIO_AUTH_TOKEN = "cd2e9c43143e2e171275223043ab087f"

stock_parameters = {
    "function": "TIME_SERIES_DAILY_ADJUSTED",
    "symbol": STOCK_NAME,
    "apikey": STOCK_APIKEY
}

response = requests.get(STOCK_ENDPOINT, params=stock_parameters)
response.raise_for_status()
data = response.json()["Time Series (Daily)"]
data_list = [value for (key, value) in data.items()]
yesterday_price = data_list[0]
yesterday_closing_price = yesterday_price["4. close"]
print(yesterday_closing_price)
day_before_yesterday_price = data_list[1]
day_before_yesterday_closing_price = day_before_yesterday_price["4. close"]
print(day_before_yesterday_closing_price)
difference = (float(yesterday_closing_price) - float(day_before_yesterday_closing_price))
up_down = None
if difference > 0:
    up_down = "🔺"
else:
    up_down = "🔻"
print(difference)
percentage_difference = round((difference / float(yesterday_closing_price)) * 100)
print(percentage_difference)
if abs(percentage_difference) > 2:
    news_parameters = {
        "qInTitle": COMPANY_NAME,
        "apikey": NEWS_APIKEY
    }
    news_response = requests.get(NEWS_ENDPOINT, params=news_parameters)
    articles = news_response.json()["articles"]
    three_articles = articles[:3]
    title_list = [f"{STOCK_NAME}: {up_down}{percentage_difference}%\nHeadline: {article['title']}\nBrief: {article['description']}" for article in three_articles]
    print(title_list)

    client = Client(TWILIO_SID, TWILIO_AUTH_TOKEN)
    for article in title_list:
        message = client.messages.create(
            body=article,
            from_="+15076697109",
            to="+917559388032"
        )



